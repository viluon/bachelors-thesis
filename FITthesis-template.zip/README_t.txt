



         Short HOWTO for Theses Template



   Use this template with LATEX 2e (TeXLive 2011 recommended). For inspira-
tion, see MastersThesis_example. Should you have any question or comment,
contact the template author mentioned in file named FITthesis.cls.
   This template is designed for double-sided printing.



1    Bachelor's Thesis


Select source file Template_BachelorsThesis.tex.  Rename it according to
this pattern: BP_Surname_Name_Year.tex. Edit the template as you need: fill
in your data, write your thesis' text etc. Use pdflatex command to process it.



2    Master's Thesis


Select source file Template_MasterssThesis.tex. Rename it according to this
pattern: DP_Surname_Name_Year.tex.  Edit the template as you need: fill in
your data, write your thesis' text etc. Use pdflatex command to process it.
